package com.mycompany.guerrero;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Batalla {
    public static void main(String[] args) {
        // Ingresar datos del líder de cada bando
        Guerrero liderGriego = new Griego("Aquiles", 30, 8);
        Guerrero liderTroyano = new Troyano("Héctor", 35, 7);

        // Ingresar la cantidad de soldados
        int cantidadSoldados = 5;

        // Generar ejércitos aleatorios
        List<Griego> ejercitoGriego = generarEjercitoGriego(liderGriego, cantidadSoldados);
        List<Troyano> ejercitoTroyano = generarEjercitoTroyano(liderTroyano, cantidadSoldados);

        // Mostrar lista de guerreros de cada bando
        System.out.println("Ejército Griego:");
        mostrarEjercito(ejercitoGriego);

        System.out.println("\nEjército Troyano:");
        mostrarEjercito(ejercitoTroyano);

        // Realizar enfrentamientos
        realizarEnfrentamientos(ejercitoGriego, ejercitoTroyano);

        // Mostrar resultados finales
        mostrarResultadosFinales(ejercitoGriego, ejercitoTroyano);
    }

    private static List<Griego> generarEjercitoGriego(Guerrero lider, int cantidadSoldados) {
        List<Griego> ejercito = new ArrayList<>();
        ejercito.add(new Griego(lider, "Soldado1"));

        Random random = new Random();
        for (int i = 1; i < cantidadSoldados; i++) {
            Griego soldado = new Griego("Soldado" + (i + 1), 15 + random.nextInt(46), 6 + random.nextInt(5));
            ejercito.add(soldado);
        }

        return ejercito;
    }

    private static List<Troyano> generarEjercitoTroyano(Guerrero lider, int cantidadSoldados) {
        List<Troyano> ejercito = new ArrayList<>();
        ejercito.add(new Troyano(lider, "Soldado1"));

        Random random = new Random();
        for (int i = 1; i < cantidadSoldados; i++) {
            Troyano soldado = new Troyano("Soldado" + (i + 1), 15 + random.nextInt(46), 6 + random.nextInt(5));
            ejercito.add(soldado);
        }

        return ejercito;
    }

    private static void mostrarEjercito(List<? extends Guerrero> ejercito) {
        for (Guerrero guerrero : ejercito) {
            System.out.println(guerrero.getNombre() + " - Edad: " + guerrero.getEdad() +
                    ", Fuerza: " + guerrero.getFuerza());
        }
    }

    private static void realizarEnfrentamientos(List<Griego> ejercitoGriego, List<Troyano> ejercitoTroyano) {
        Random random = new Random();
        for (Griego griego : ejercitoGriego) {
            Troyano troyano = ejercitoTroyano.get(random.nextInt(ejercitoTroyano.size()));

            int ataqueGriego = random.nextInt(10) + 1;
            int ataqueTroyano = random.nextInt(10) + 1;

            System.out.println(griego.getNombre() + " atacó a " + troyano.getNombre() + ", " +
                    ataqueGriego + " de daño.");

            troyano.recibirAtaque(ataqueGriego);

            System.out.println("Estado actual de " + troyano.getNombre() + ": " +
                    obtenerEstado(griego));

            if (!troyano.isMuerto()) {
                System.out.println(troyano.getNombre() + " contraatacó, " +
                        ataqueTroyano + " de daño.");

                griego.recibirAtaque(ataqueTroyano);

                System.out.println("Estado actual de " + griego.getNombre() + ": " +
                        obtenerEstado(griego));
            }

            System.out.println(); // Separador entre enfrentamientos
        }
    }

    private static String obtenerEstado(Guerrero guerrero) {
        if (guerrero.isMuerto()) {
            return "Muerto";
        } else if (guerrero.isHerido() && guerrero.retirarse()) {
            return "Herido/Retirado";
        } else if (guerrero.isHerido()) {
            return "Herido";
        } else {
            return "Vivo";
        }
    }

    private static void mostrarResultadosFinales(List<Griego> ejercitoGriego, List<Troyano> ejercitoTroyano) {
    System.out.println("---- Resultados Finales ----");

    int bajasTroyanos = contarBajas(ejercitoTroyano);
    int bajasGriegos = contarBajas(ejercitoGriego);

    System.out.println("Número de bajas troyanas: " + bajasTroyanos);
    System.out.println("Número de bajas griegas: " + bajasGriegos);

    if (bajasTroyanos > bajasGriegos) {
        System.out.println("Ganaron los troyanos");
    } else if (bajasGriegos > bajasTroyanos) {
        System.out.println("Ganaron los griegos");
    } else {
        System.out.println("La batalla terminó en empate");
    }

    int totalBajas = bajasTroyanos + bajasGriegos;
    System.out.println("Total de bajas: " + totalBajas);

    // Mostrar guerreros que quedaron vivos
    System.out.println("\nGuerreros que quedaron vivos:");

    for (Griego griego : ejercitoGriego) {
        if (!griego.isMuerto()) {
            System.out.println("Griego " + griego.getNombre() + " 👑");
        }
    }

    for (Troyano troyano : ejercitoTroyano) {
        if (!troyano.isMuerto()) {
            System.out.println("Troyano " + troyano.getNombre() + " 👑");
        }
    }
}

private static int contarBajas(List<? extends Guerrero> ejercito) {
    int bajas = 0;
    for (Guerrero guerrero : ejercito) {
        if (guerrero.isMuerto()) {
            bajas++;
        }
    }
    return bajas;
}

}
