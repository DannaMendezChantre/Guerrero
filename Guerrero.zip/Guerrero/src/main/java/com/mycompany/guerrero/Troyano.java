
package com.mycompany.guerrero;

class Troyano extends Guerrero {
    public Troyano(String nombre, int edad, int fuerza) {
        super(nombre, edad, fuerza);
    }

    public Troyano() {
        super();
    }

    public Troyano(Guerrero otroGuerrero, String nombre) {
        super(otroGuerrero, nombre);
    }

    @Override
    public boolean retirarse() {
        return false; // Los troyanos no se pueden retirar
    }
}

