/*
 *@autor Danna Zharick Mendez Chantre
 *@autor Brayan Andres Carrillo Quiñones
 */


package com.mycompany.guerrero;

class Griego extends Guerrero {
    public Griego(String nombre, int edad, int fuerza) {
        super(nombre, edad, fuerza);
    }

    public Griego() {
        super();
    }

    public Griego(Guerrero otroGuerrero, String nombre) {
        super(otroGuerrero, nombre);
    }

    @Override
    public boolean retirarse() {
        return (this.herido && !this.muerto);
    }
}
